def adding(n_1, n_2):
    return n_1 - n_2